package assignment;
import assignment.innerClass2;
public class innerClass3 {
	

		public static void main(String[] args) {
		innerClass i = new innerClass() {

		         public void display() {
		            System.out.println("Anonymous Inner Class");
		         }
		      };
		      i.display();
		   }
		}

