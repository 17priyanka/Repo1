package assignment;
import assignment.innerClass2;
public class innerClass2 {
	
	

		
			//public class innerClassAssisted1 {

				 private String msg="Welcome to Java"; 
				 
				 class Inner{  
				  void hello(){System.out.println(msg+", Let us start learning Inner Classes");}  
				 }  


				public static void main(String[] args) {

					innerClass obj=new innerClass();
					innerClass.Inner in=obj.new Inner();  
					in.hello();  
					innerClass2  ob=new innerClass2 ();  
					ob.display();  
					abstract class AnonymousInnerClass {
						   public abstract void display();
						}
				}


				
					
				}
	

		
}


